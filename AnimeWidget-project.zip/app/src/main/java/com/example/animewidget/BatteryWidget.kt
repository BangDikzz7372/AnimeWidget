package com.example.animewidget

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.os.BatteryManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider

data class BatteryInfo(val percent: Int, val charging: Boolean)

fun readBattery(context: Context): BatteryInfo {
    val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL
    val percent = if (level >= 0 && scale > 0) level * 100 / scale else 0
    return BatteryInfo(percent, charging)
}

/** Pilih gambar sesuai kondisi baterai; cadangan ke gambar utama. */
private fun pickBitmap(context: Context, info: BatteryInfo): Bitmap? {
    if (WidgetSettings.perState(context)) {
        val state = when {
            info.charging -> "img_charging"
            info.percent >= 60 -> "img_high"
            info.percent >= 30 -> "img_mid"
            else -> "img_low"
        }
        ImageStore.load(context, state)?.let { return it }
    }
    return ImageStore.load(context, "img_all")
}

class BatteryWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val info = readBattery(context)
        val bitmap = pickBitmap(context, info)
        val bgColor = WidgetSettings.bgColor(context)
        val textColor = WidgetSettings.textColor(context)
        val cornerDp = WidgetSettings.cornerDp(context)
        provideContent {
            BatteryContent(info, bitmap, bgColor, textColor, cornerDp)
        }
    }
}

@Composable
private fun BatteryContent(
    info: BatteryInfo,
    bitmap: Bitmap?,
    bgColor: Int,
    textColor: Int,
    cornerDp: Int
) {
    val status = when {
        info.charging -> "Mengisi daya"
        info.percent >= 60 -> "Aman"
        info.percent >= 30 -> "Mulai hemat ya"
        else -> "Colok charger!"
    }
    val imageProvider = if (bitmap != null) {
        ImageProvider(bitmap)
    } else {
        ImageProvider(R.drawable.placeholder)
    }

    Row(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(Color(bgColor)))
            .cornerRadius(cornerDp.dp)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            provider = imageProvider,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = GlanceModifier.size(88.dp).cornerRadius((cornerDp / 2).dp)
        )
        Spacer(modifier = GlanceModifier.width(12.dp))
        Column {
            Text(
                text = "${info.percent}%",
                style = TextStyle(
                    color = ColorProvider(Color(textColor)),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold
                )
            )
            Text(
                text = status,
                style = TextStyle(
                    color = ColorProvider(Color(textColor).copy(alpha = 0.75f)),
                    fontSize = 14.sp
                )
            )
        }
    }
}
