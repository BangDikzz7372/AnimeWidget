package com.example.animewidget

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : Activity() {

    private val slotNames = listOf("img_all", "img_high", "img_mid", "img_low", "img_charging")
    private val slotLabels = listOf(
        "Gambar utama",
        "Baterai tinggi (60% ke atas)",
        "Baterai sedang (30-59%)",
        "Baterai rendah (di bawah 30%)",
        "Sedang mengisi daya"
    )
    private val previews = arrayOfNulls<ImageView>(5)
    private val stateRows = mutableListOf<View>()

    private val bgPalette = listOf(
        0xE61B1B2F.toInt(), 0xE6000000.toInt(), 0xE6FFFFFF.toInt(),
        0xE63A2A4F.toInt(), 0xE61F3A2E.toInt(), 0x00000000
    )
    private val textPalette = listOf(
        0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFFB6D9.toInt(),
        0xFFC9B6FF.toInt(), 0xFFA8E6C1.toInt(), 0xFFFFD54F.toInt()
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(label("Anime Widget", 26f, true))
        root.addView(label("Pilih gambar karakter dari galeri HP, lalu atur tampilan widget baterai.", 14f, false))

        root.addView(section("Gambar karakter"))
        root.addView(slotRow(0))

        val perState = Switch(this).apply {
            text = "Gambar berbeda tiap kondisi baterai"
            isChecked = WidgetSettings.perState(this@MainActivity)
            setPadding(0, dp(12), 0, dp(12))
            setOnCheckedChangeListener { _, checked ->
                WidgetSettings.setPerState(this@MainActivity, checked)
                applyStateRowsVisibility(checked)
                pushUpdate()
            }
        }
        root.addView(perState)

        for (i in 1..4) {
            val row = slotRow(i)
            stateRows.add(row)
            root.addView(row)
        }
        applyStateRowsVisibility(perState.isChecked)

        root.addView(section("Warna latar"))
        root.addView(swatchRow(bgPalette) {
            WidgetSettings.setBgColor(this, it)
            pushUpdate()
        })

        root.addView(section("Warna teks"))
        root.addView(swatchRow(textPalette) {
            WidgetSettings.setTextColor(this, it)
            pushUpdate()
        })

        root.addView(section("Sudut membulat"))
        val cornerLabel = label("", 14f, false)
        val corner = WidgetSettings.cornerDp(this)
        cornerLabel.text = "$corner dp"
        root.addView(cornerLabel)
        root.addView(SeekBar(this).apply {
            max = 40
            progress = corner
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    cornerLabel.text = "$p dp"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    WidgetSettings.setCornerDp(this@MainActivity, progress)
                    pushUpdate()
                }
            })
        })

        root.addView(Button(this).apply {
            text = "Hapus semua gambar"
            setOnClickListener {
                slotNames.forEachIndexed { i, n ->
                    ImageStore.delete(this@MainActivity, n)
                    refreshPreview(i)
                }
                pushUpdate()
            }
        })

        root.addView(section("Cara pasang widget"))
        root.addView(label("Tekan lama layar utama HP, pilih Widget, cari \"Anime Widget\", lalu seret ke layar.", 14f, false))

        for (i in slotNames.indices) refreshPreview(i)
    }

    private fun label(t: String, sizeSp: Float, bold: Boolean) = TextView(this).apply {
        text = t
        textSize = sizeSp
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun section(t: String) = label(t, 18f, true).apply {
        setPadding(0, dp(24), 0, dp(4))
    }

    private fun slotRow(index: Int): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val preview = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0x22888888)
        }
        previews[index] = preview
        val text = TextView(this).apply {
            text = slotLabels[index]
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(12)
                marginEnd = dp(8)
            }
        }
        val button = Button(this).apply {
            text = "Pilih"
            setOnClickListener { pickImage(index) }
        }
        row.addView(preview)
        row.addView(text)
        row.addView(button)
        return row
    }

    private fun swatchRow(colors: List<Int>, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
        }
        for (c in colors) {
            val swatch = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(10) }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    setStroke(dp(2), 0x66888888)
                }
                setOnClickListener { onPick(c) }
            }
            row.addView(swatch)
        }
        return row
    }

    private fun applyStateRowsVisibility(show: Boolean) {
        stateRows.forEach { it.visibility = if (show) View.VISIBLE else View.GONE }
    }

    private fun refreshPreview(index: Int) {
        previews[index]?.setImageBitmap(ImageStore.load(this, slotNames[index]))
    }

    private fun pushUpdate() {
        CoroutineScope(Dispatchers.Main).launch {
            BatteryWidget().updateAll(applicationContext)
        }
    }

    private fun pickImage(index: Int) {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(Intent.createChooser(intent, "Pilih gambar"), REQ_BASE + index)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val index = requestCode - REQ_BASE
        if (resultCode != RESULT_OK || index !in slotNames.indices) return
        val uri = data?.data ?: return
        if (ImageStore.save(this, uri, slotNames[index])) {
            refreshPreview(index)
            pushUpdate()
        } else {
            Toast.makeText(this, "Gambar gagal dibaca", Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        private const val REQ_BASE = 1000
    }
}
