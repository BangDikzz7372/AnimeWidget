package com.example.animewidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/** Pengaturan tampilan widget, disimpan di SharedPreferences. */
object WidgetSettings {
    private const val PREFS = "widget_prefs"

    val DEFAULT_BG: Int = 0xE61B1B2F.toInt()
    val DEFAULT_TEXT: Int = 0xFFFFFFFF.toInt()
    const val DEFAULT_CORNER = 24

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun perState(c: Context): Boolean = prefs(c).getBoolean("per_state", false)
    fun setPerState(c: Context, v: Boolean) = prefs(c).edit().putBoolean("per_state", v).apply()

    fun bgColor(c: Context): Int = prefs(c).getInt("bg_color", DEFAULT_BG)
    fun setBgColor(c: Context, v: Int) = prefs(c).edit().putInt("bg_color", v).apply()

    fun textColor(c: Context): Int = prefs(c).getInt("text_color", DEFAULT_TEXT)
    fun setTextColor(c: Context, v: Int) = prefs(c).edit().putInt("text_color", v).apply()

    fun cornerDp(c: Context): Int = prefs(c).getInt("corner_dp", DEFAULT_CORNER)
    fun setCornerDp(c: Context, v: Int) = prefs(c).edit().putInt("corner_dp", v).apply()
}

/** Menyimpan gambar pilihan pengguna di penyimpanan internal aplikasi. */
object ImageStore {
    private const val MAX_SIDE = 512

    private fun file(c: Context, name: String) = File(c.filesDir, "$name.png")

    fun load(c: Context, name: String): Bitmap? {
        val f = file(c, name)
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    }

    fun delete(c: Context, name: String) {
        file(c, name).delete()
    }

    fun save(c: Context, uri: android.net.Uri, name: String): Boolean {
        return try {
            val resolver = c.contentResolver

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val longestRaw = maxOf(bounds.outWidth, bounds.outHeight)
            if (longestRaw <= 0) return false

            var sample = 1
            while (longestRaw / sample > MAX_SIDE * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return false

            val longest = maxOf(bmp.width, bmp.height)
            val out = if (longest > MAX_SIDE) {
                val r = MAX_SIDE.toFloat() / longest
                Bitmap.createScaledBitmap(
                    bmp,
                    (bmp.width * r).toInt().coerceAtLeast(1),
                    (bmp.height * r).toInt().coerceAtLeast(1),
                    true
                )
            } else bmp

            file(c, name).outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            true
        } catch (e: Exception) {
            false
        }
    }
}
