# Anime Widget

Widget baterai dengan gambar karakter pilihan sendiri.

## Fitur
- Pilih gambar dari galeri (satu gambar, atau beda tiap kondisi baterai)
- Atur warna latar, warna teks, dan sudut membulat
- Widget diperbarui saat charger dicolok/dicabut, saat baterai rendah/normal,
  dan berkala sekitar 30 menit

Aplikasi tidak membawa gambar karakter apa pun. Gambar sepenuhnya dari pengguna
dan hanya tersimpan di HP masing-masing.

## Pasang widget
Tekan lama layar utama -> Widget -> Anime Widget -> seret ke layar.
